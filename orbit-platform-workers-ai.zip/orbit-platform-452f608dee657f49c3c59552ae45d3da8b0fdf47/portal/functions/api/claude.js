// Cloudflare Pages Function backed by Workers AI (no Anthropic key required).
// Requires the Cloudflare AI binding named AI in wrangler.toml / Pages settings.
const HEADERS = {
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Content-Type": "application/json; charset=utf-8",
  "Cache-Control": "no-store",
  "X-Content-Type-Options": "nosniff"
};
const json = (data, status = 200) => new Response(JSON.stringify(data), { status, headers: HEADERS });
export async function onRequestOptions() { return new Response(null, { status: 204, headers: HEADERS }); }
function normalizeMessages(messages, system) {
  const out = [];
  if (typeof system === "string" && system.trim()) out.push({ role: "system", content: system });
  for (const m of messages) {
    if (!m || !["user", "assistant", "system"].includes(m.role)) continue;
    let content = m.content;
    if (Array.isArray(content)) content = content.map(x => typeof x === "string" ? x : (x && (x.text || x.content)) || "").join("\n");
    if (typeof content === "string" && content.trim()) out.push({ role: m.role, content: content.slice(0, 12000) });
  }
  return out.slice(-20);
}
export async function onRequestPost({ request, env }) {
  try {
    if (!env.AI || typeof env.AI.run !== "function") return json({ text: null, error: "Workers AI is not configured. Add the AI binding to this Pages project." }, 503);
    const body = await request.json().catch(() => null);
    if (!body || !Array.isArray(body.messages)) return json({ text: null, error: "messages must be an array" }, 400);
    const messages = normalizeMessages(body.messages, body.system);
    if (!messages.length) return json({ text: null, error: "No usable messages provided" }, 400);
    const model = env.WORKERS_AI_MODEL || "@cf/meta/llama-3.1-8b-instruct";
    const result = await env.AI.run(model, { messages, max_tokens: Math.min(Math.max(Number(body.max_tokens) || 500, 1), 1200), temperature: 0.2 });
    const text = result && (result.response || result.result || result.output_text || (result.choices && result.choices[0] && result.choices[0].message && result.choices[0].message.content));
    if (typeof text !== "string" || !text.trim()) return json({ text: null, error: "Workers AI returned no text" }, 502);
    return json({ text: text.trim(), provider: "cloudflare-workers-ai", model });
  } catch (error) {
    return json({ text: null, error: "Unable to process AI request with Workers AI." }, 502);
  }
}
