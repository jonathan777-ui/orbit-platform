# Orbit4 — Cloudflare Pages package

This folder is the Cloudflare Pages project root. It contains the static Orbit/Alyxir portal and Pages Functions.

## Deploy settings
- Project root: `portal/`
- Build command: none
- Build output directory: `.`
- Functions: `functions/api/`

## API routes
- `POST /api/claude` — optional live Anthropic answers for the chatbot/receptionist.
- `POST /api/enrich` — best-effort business website/logo/brand discovery.

## Cloudflare variables and secrets
- `Workers AI binding (`AI`)` — secret; enables live AI answers and online business discovery. Without it, the hub falls back to the built-in knowledge base and Company + Hours only.
- `MODEL` — optional, defaults to `claude-haiku-4-5-20251001`.
- `ENRICH_MODEL` — optional model for web-search discovery.

Set variables under Cloudflare Dashboard → Workers & Pages → your Pages project → Settings → Variables and Secrets. Do not put secrets in HTML or commit them to Git.

See [`../CLOUDFLARE-MIGRATION.md`](../CLOUDFLARE-MIGRATION.md) for deployment, preview testing, and domain cutover steps.
