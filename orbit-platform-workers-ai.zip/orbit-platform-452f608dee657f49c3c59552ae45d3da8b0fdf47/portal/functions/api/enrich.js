// Orbit enrichment — finds a business's website, logo, brand color, description & services
// from just a name (+ optional city/state). Uses no external LLM key; ALWAYS degrades gracefully so the hub falls
// back to Company name + Hours of Operation. Logo/brand discovery from the homepage needs
// no key (it just reads public <meta>/<link> tags), with a Google-favicon fallback.

const CORS = {
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Content-Type": "application/json; charset=utf-8",
  "Cache-Control": "no-store"
};
const json = (data, status = 200) => new Response(JSON.stringify(data), { status, headers: CORS });

function hostOf(u) {
  if (!u) return "";
  try { return new URL(/^https?:\/\//.test(u) ? u : "https://" + u).hostname.replace(/^www\./, ""); }
  catch (e) { return ""; }
}
function normalize(u) {
  if (!u) return "";
  return /^https?:\/\//.test(u) ? u : "https://" + u;
}

export async function onRequestOptions() {
  return new Response(null, { status: 204, headers: CORS });
}

export async function onRequestPost({ request, env }) {
  const ok = (obj) => json(obj);
  try {
    const { name, city, state, url, hours } = await request.json().catch(() => ({}));
    if (!name) return ok({ found: false, reason: "no business name" });

    let website = (url || "").trim();
    // Workers AI does not provide Anthropic's built-in web_search tool. Avoid
    // pretending that business discovery happened: use a supplied URL and read
    // only publicly accessible homepage metadata. Full search can be added later
    // with a separately configured Cloudflare search product.
    const facts = {};

    // 2) Derive logo + accent + description from the homepage (no API key required).
    let logo = "", accent = (facts.brand_color_hex || "").trim();
    let desc = (facts.one_line_description || "").trim();
    let services = Array.isArray(facts.services) ? facts.services.filter(Boolean).slice(0, 6) : [];
    const domain = hostOf(website);

    if (domain) {
      try {
        const resp = await fetch(normalize(website), {
          headers: { "user-agent": "Mozilla/5.0 (compatible; OrbitBot/1.0)" },
          redirect: "follow"
        });
        const html = (await resp.text()).slice(0, 400000);
        const pick = (re) => { const x = html.match(re); return x ? x[1].trim() : ""; };
        const abs = (u) => {
          if (!u) return "";
          if (/^https?:\/\//.test(u)) return u;
          if (u.indexOf("//") === 0) return "https:" + u;
          if (u.charAt(0) === "/") return "https://" + domain + u;
          return "https://" + domain + "/" + u;
        };
        const apple = pick(/<link[^>]+rel=["'][^"']*apple-touch-icon[^"']*["'][^>]*href=["']([^"']+)["']/i)
          || pick(/<link[^>]+href=["']([^"']+)["'][^>]*rel=["'][^"']*apple-touch-icon/i);
        const ogimg = pick(/<meta[^>]+property=["']og:image["'][^>]*content=["']([^"']+)["']/i)
          || pick(/<meta[^>]+content=["']([^"']+)["'][^>]*property=["']og:image["']/i);
        const iconL = pick(/<link[^>]+rel=["'](?:icon|shortcut icon)["'][^>]*href=["']([^"']+)["']/i);
        const themeC = pick(/<meta[^>]+name=["']theme-color["'][^>]*content=["']([^"']+)["']/i);
        if (!desc) desc = pick(/<meta[^>]+name=["']description["'][^>]*content=["']([^"']+)["']/i);
        if (!accent && themeC) {
          const c = themeC.charAt(0) === "#" ? themeC : "#" + themeC;
          if (/^#[0-9a-f]{3,8}$/i.test(c)) accent = c;
        }
        logo = abs(apple) || abs(ogimg) || abs(iconL);
      } catch (e) { /* page fetch failed — use favicon fallback below */ }
      if (!logo) logo = "https://www.google.com/s2/favicons?sz=128&domain=" + domain;
    }

    const found = !!(website || logo || desc || services.length);
    return ok({
      found: found,
      website: website || "",
      domain: domain || "",
      logo: logo || "",
      accent: accent || "",
      description: desc || "",
      services: services,
      hours: (facts.hours || hours || ""),
      verify: true,
      note: "Workers AI migration: automatic web search is not configured. Supply the business website URL to extract public homepage metadata."
    });
  } catch (e) {
    return ok({ found: false, error: String(e) });
  }
}

