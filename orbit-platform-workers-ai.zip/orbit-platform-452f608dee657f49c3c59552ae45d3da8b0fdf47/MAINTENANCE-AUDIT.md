# Orbit / Alyxir Maintenance Audit — Follow-up Pass

## Scope

Follow-up static review of the complete supplied ZIP. Changes were made only in this working copy; the original upload is preserved.

## Verified checks

- Archive extraction and ZIP integrity: passed.
- Python syntax compilation: `site/build.py` and all three `skills/airlock-vertical-kb/tools/*.py` files passed.
- JavaScript syntax: the migrated Cloudflare Pages Functions (`portal/functions/api/claude.js` and `enrich.js`) passed `node --check`.
- HTML local-reference scan: 43 HTML files checked; zero missing local `href`, `src`, or `action` targets were found.
- Duplicate HTML ID scan: zero duplicate IDs found in the 43 HTML files.
- Exact SHA-256 duplicate scan found repeated files; see below. Duplicates were not deleted where they appear to be route aliases, documented mirrors, or knowledge-base assets.

## Exact duplicate files reviewed

- `portal/index.html` and `portal/orbit.html` — identical; retained because both are entry routes and other pages link to `orbit.html`.
- `skills/airlock-vertical-kb/references/compliance-patterns.md` and `portal/support-portal/kb-library/03-compliance-patterns.md` — identical cross-area reference copy; retained because the skill and portal library have separate uses.
- `portal/alyxir-kb-mastery-map-25-verticals.md` and `portal/support-portal/runbooks/alyxir-kb-mastery-map-25-verticals.md` — retained as portal/runbook mirror.
- `portal/alyxir-build-launch-handoff.md` and `portal/support-portal/runbooks/alyxir-build-launch-handoff.md` — retained as portal/runbook mirror.
- `portal/orbit-n8n-generate-kb-setup.md` and `portal/support-portal/runbooks/orbit-n8n-generate-kb-setup.md` — retained as portal/runbook mirror.
- `portal/alyxir-backend-stack-vendors.md` and `portal/support-portal/runbooks/alyxir-backend-stack-vendors.md` — retained as portal/runbook mirror.
- `portal/alyxir-language-dialect-layer-v2.md` and `portal/support-portal/runbooks/alyxir-language-dialect-layer-v2.md` — retained as portal/runbook mirror.
- `portal/alyxir-asset-review-and-upgrades.md` and `portal/support-portal/runbooks/alyxir-asset-review-and-upgrades.md` — retained as portal/runbook mirror.
- `portal/alyxir-proving-ground-eval-qa-map.md` and `portal/support-portal/runbooks/alyxir-proving-ground-eval-qa-map.md` — retained as portal/runbook mirror.
- `portal/alyxir-kb-packages-module.md` and `portal/support-portal/runbooks/alyxir-kb-packages-module.md` — retained as portal/runbook mirror.
- `portal/alyxir-portal-gurus-architecture.md` and `portal/support-portal/runbooks/alyxir-portal-gurus-architecture.md` — retained as portal/runbook mirror.
- `portal/alyxir-lead-lookup-setup.md` and `portal/support-portal/runbooks/alyxir-lead-lookup-setup.md` — retained as portal/runbook mirror.

These files are byte-identical but not necessarily worthless: some are separate public routes or organized copies that the portal expects. Deleting them without changing links/navigation would risk regressions.

## Cloudflare migration preparation

- Added `portal/functions/api/claude.js` and `portal/functions/api/enrich.js` as Cloudflare Pages Functions, using Cloudflare `env` bindings instead of Netlify `process.env` and Netlify event objects.
- Updated the Orbit/TrackDog front-end API calls to `/api/claude` and `/api/enrich`.
- Added `portal/wrangler.toml`, `portal/_headers`, and `CLOUDFLARE-MIGRATION.md`; updated active deployment instructions and portal README.
- Removed `portal/netlify.toml` and the duplicate Netlify function directory from this Cloudflare-targeted bundle. The separate GitHub Pages docs workflow remains unchanged.
- The TrackDog preview now uses browser speech when the missing TTS backend is not available. Team access remains demo-only because the bundle has no server-side verification-send implementation; the migration notes explicitly flag that limitation.
- Cloudflare Pages deploy, account secrets, DNS cutover, and live API/integration tests have not been run because no Cloudflare account or credentials were supplied.

## Changes in this follow-up pass

- Expanded this audit with reproducible validation results and the complete list of exact duplicate pairs reviewed.
- Removed generated Python `__pycache__` and `.pyc` artifacts created during validation.
- No application features or source files were deleted because static evidence did not prove they were dead or safe to remove.

## Not verified / limitations

- The Python `markdown` package is not installed, so `site/build.py` was syntax-checked but its generated documentation build was not run.
- No root `package.json` or automated browser-test suite is present. JSX files require a JSX-aware compiler; plain `node --check` is not a valid test for JSX.
- API keys, Cloudflare Functions against deployed services, voice/receptionist flows, booking, external webhooks, calendar/email automation, and authentication require credentials and live services. They were not tested end-to-end.
- Static HTML scanning does not discover every URL assembled dynamically in JavaScript, external links that may be down, or runtime errors.

## Recommended next step

Run a browser-based smoke test against a deployed preview and test each primary workflow with test credentials before deleting any more pages or mirrored documents. For future cleanup, convert repeated runbooks into one canonical source only after adding redirects or updating every navigation and download link.
