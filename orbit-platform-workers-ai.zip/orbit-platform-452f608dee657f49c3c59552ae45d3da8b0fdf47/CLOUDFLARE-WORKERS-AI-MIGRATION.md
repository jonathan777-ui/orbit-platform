# Cloudflare Workers AI migration report

## Changes
- Replaced the `/api/claude` provider implementation with Cloudflare Workers AI (`env.AI.run`). No Anthropic API key is needed for this endpoint.
- Added the `AI` binding to `portal/wrangler.toml`. If deploying via the dashboard, ensure the Workers AI binding named `AI` is enabled for the Pages project.
- Migrated browser-side Anthropic API calls in the proving-ground demos, merge engine, standalone Airlock app, and website audit toward the same-origin `/api/claude` endpoint where the source pattern could be safely adapted. This avoids exposing provider requests from the browser.
- Removed Anthropic web-search use from `/api/enrich`. Workers AI does not itself provide Anthropic's built-in web_search tool. Enrichment now extracts public metadata from a business URL supplied by the user; automatic discovery by business name alone is not guaranteed.

## Deploy
1. Set `portal/` as the Cloudflare Pages project root and `.` as the build output directory.
2. Enable Workers AI and bind it as `AI` (or deploy with the included `portal/wrangler.toml`).
3. The default model is `@cf/meta/llama-3.1-8b-instruct`; optionally override with a supported model ID using the `WORKERS_AI_MODEL` environment variable. Model availability and account limits depend on Cloudflare.
4. Test `/api/claude` with a POST JSON body such as `{"system":"Be concise","messages":[{"role":"user","content":"Say hello"}]}`.
5. Test receptionist scenarios, JSON QA evaluation, and homepage metadata enrichment on a preview deployment before switching production traffic.

## Known limitations / incompatible features
- Workers AI model output is not guaranteed to match Claude's quality, format, or reasoning; QA/scoring results may differ and should be recalibrated.
- The prior enrichment route used Anthropic's built-in `web_search` tool. That capability was removed, not replicated. To restore automated discovery, integrate a separately configured search API or Cloudflare product.
- Telnyx, Deepgram, ElevenLabs, Attio, n8n, SMS, live telephony, and external calendar/booking integrations remain separate services and may still require their own credentials.
- The legacy `api.anthropic.com` browser endpoint has been removed from application HTML. References to Anthropic in strategy notes or old handoff documentation may remain as historical context and should not be treated as active runtime dependencies.
- No live Cloudflare deployment or account-level integration test was performed in this local ZIP review.
