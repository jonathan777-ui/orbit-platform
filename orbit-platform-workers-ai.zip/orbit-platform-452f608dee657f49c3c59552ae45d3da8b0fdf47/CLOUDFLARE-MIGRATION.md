# Orbit / Alyxir — Cloudflare Pages migration

This bundle is prepared for **Cloudflare Pages + Pages Functions**. It does not change DNS or deploy to an account automatically.

## Deployment settings

- **Project root / root directory:** `portal/`
- **Build command:** leave empty (the portal is static HTML)
- **Build output directory:** `.`
- **Functions:** `portal/functions/api/`
- **Routes:** `POST /api/claude`, `POST /api/enrich`
- **Secret:** `Workers AI binding (`AI`)` (Cloudflare Pages → Settings → Variables and Secrets; mark as secret)
- **Security:** add Cloudflare rate limiting / WAF rules for `/api/*` before exposing the live AI proxy publicly. The API key is server-side, but the public endpoint can still be abused if left unrestricted.
- **Optional variables:** `MODEL`, `ENRICH_MODEL`

Connect the repository in Cloudflare Dashboard → Workers & Pages → Create → Pages → Connect to Git. Select the branch you deploy from and apply the settings above. The `portal/wrangler.toml` file records the Pages output directory and compatibility date.

For local testing, install a supported Node.js version and Wrangler, then run from `portal/`:

```sh
npx wrangler pages dev .
```

For production, deploy through the Git integration or Wrangler with the project already created. Do not use the static-only dashboard upload workflow if you need the Pages Functions; Cloudflare's docs state that dashboard Direct Upload does not support Functions.

## Before switching the live domain

1. Deploy to the generated `*.pages.dev` preview URL first.
2. Verify `/`, `/orbit.html`, `/orbit-call-widget.html`, and the portal navigation.
3. Test `POST /api/claude` with `Workers AI binding (`AI`)` configured, then test it without a key to confirm the offline fallback.
4. Test `POST /api/enrich` with and without the key. External websites may block automated homepage fetches; enrichment must remain best-effort.
5. Check browser console, mobile layout, authentication/access expectations, and all external integrations (Anthropic, telephony, CRM, n8n, calendar, webhooks). These are not migrated merely by moving hosting.
6. Only after the preview passes, connect the custom domain and change DNS to the Cloudflare Pages target. Keep the Netlify deployment available for rollback until the new domain is verified.

## Function migration notes

- Netlify function paths `/.netlify/functions/claude` and `/.netlify/functions/enrich` were changed to `/api/claude` and `/api/enrich` in the portal HTML clients.
- Netlify handlers were ported to Cloudflare Pages method handlers using `request`, `env`, and standard `Response` objects.
- The Anthropic API key is read from Cloudflare's `env.Workers AI binding (`AI`)`; never place the key in HTML or commit it to Git. API responses do not enable wildcard CORS; keep frontend calls same-origin unless you intentionally configure an origin allowlist.
- Netlify-specific deployment files and duplicate Netlify function copies were removed from this Cloudflare-targeted bundle. Historical documentation may still mention Netlify where it describes prior decisions or legacy workflows.
- This is a migration-ready bundle, not a claim that a live Cloudflare deployment or external integrations have been verified. DNS, Cloudflare account settings, secrets, and credentials require owner access.

## Known items not migrated as backend services

- The source bundle contains no `/api/tts` or verification-send implementation. The TrackDog preview now uses browser speech synthesis instead of calling a missing Netlify TTS route. The team-access page uses its existing demo fallback and is **not production authentication**: it contains seeded demo credentials and locally generated codes. Do not expose it as a secure staff login until server-side identity verification and delivery are implemented.
- External integrations (telephony, CRM, n8n, calendar, email/SMS) require their own endpoints, secrets, and end-to-end testing. They are not automatically moved by this static-hosting migration.
